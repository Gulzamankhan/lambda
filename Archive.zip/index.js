var AWS = require('aws-sdk');
var AWSCognito = require('amazon-cognito-identity-js');

console.log('Loading function');

exports.handler = function(event, context, callback) {

  AWS.config.region = 'eu-west-2';
  var poolData = {
    UserPoolId : 'us-west-2_letkEJ1ac',
    ClientId : '2k720ihf9d8lseo9ai8b610oq7'
  };
  var userPool = new AWS.CognitoIdentityServiceProvider.CognitoUserPool(poolData);

  var authenticationData = {
          Username : 'mohsin.khan',
          Password : 'Abc@12345',
      };
  var authenticationDetails = new AWS.CognitoIdentityServiceProvider.AuthenticationDetails(authenticationData);

  var userData = {
    Username : 'mohsin.khan',
    Pool : userPool
  };

  var cognitoUser = new AWS.CognitoIdentityServiceProvider.CognitoUser(userData);
  var resultant;
  cognitoUser.authenticateUser(authenticationDetails, {
    onSuccess: function (result) {
        console.log('access token + ' + result.getAccessToken().getJwtToken());
        /*Use the idToken for Logins Map when Federating User Pools with Cognito Identity or when passing through an Authorization Header to an API Gateway Authorizer*/
        console.log('idToken + ' + result.idToken.jwtToken);
        resultant = result.getAccessToken().getJwtToken()+result.idToken.jwtToken;
    },
    onFailure: function(err) {
        console.log(err);
        resultant = err;
    },
  });

    callback(null, resultant);
};
